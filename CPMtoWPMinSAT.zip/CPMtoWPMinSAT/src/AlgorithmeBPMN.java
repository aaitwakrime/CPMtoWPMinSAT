import java.io.*;
import org.jdom.*;
import org.jdom.input.*;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.ListIterator;
import java.io.File;

public class AlgorithmeBPMN
{

	static Document document;
	static Element racine, element;
	static String valAttributElement,refIG, refTask, refEG,refGNext,configIG,directIG,nomIG,directEG,nomEG,refTNext,refIGP;
	static List <String> listResultat = new ArrayList() ;
	
	public static void main(String[] args)
	{
		try
		{
			lireFichier("xml_bpmn/bpmn2.xml");
			connecteurS1();
			connecteurS2();
			connecteurJ1();
			connecteurJ2();
			connecteurS3();
			connecteurJ3();
			EnregistrerTxt ();
		} 
		catch (Exception e) {}
	}

	// M�thode pour parser le fichier XML
	static void lireFichier(String fichier) throws Exception 
	{
		SAXBuilder sxb = new SAXBuilder(); // on cr�e une instance de SAXBuilder
		document = sxb.build(new File(fichier)); // on cr�e un nouveau document JDOM avec en arguement le fichier XML
		racine = document.getRootElement(); // on initialise un nouvel element racine avec l'element racine du document
		System.out.println("Etape 1 : Le parsing du XML est termin�");
	}
	
	// M�thode pour le connecteur s1 : OR, Configurable, Diverging (Split) : 1 entr�e a1 (<task>) et 2 sorties S2 (<exclusiveGateway>) + J2 (<inclusiveGateway>)
	static void connecteurS1() throws Exception
	{
		List <String> listSourcesSFs = afficheListAttributs("sequenceFlow","sourceRef"); // liste des sources de sequenceFlow
		List <String> listTargetsSFs = afficheListAttributs("sequenceFlow","targetRef"); // liste des targets de sequenceFlow
		List <String> listIdIGs = afficheListAttributs("inclusiveGateway","id"); // liste des inclusiveGateway
		
		List listIG = racine.getChildren("inclusiveGateway"); // liste des enfants <inclusiveGateway>
		List listTask = racine.getChildren("task"); // liste des enfants <task>
		List listEG = racine.getChildren("exclusiveGateway"); // liste des enfants <exclusiveGateway>
		
		Iterator  iIG = listIG.listIterator(); // iterator sur <inclusiveGateway>
		Iterator iTask = listTask.iterator(); // iterator sur <task>
		Iterator iEG = listEG.iterator(); // iterator sur <exclusiveGateway>

		Element eGNext,eIG,eTask,eEG; 
		boolean stop = false; //stop prend true si le r�sultat est obtenu sinon false par d�faut
		
		while (iIG.hasNext() && iTask.hasNext() && iEG.hasNext()) //boucle pour parcourir tout le fichier XML
		{
			eIG = (Element) iIG.next(); //Element <inclusiveGateway>
			eTask= (Element) iTask.next(); //Element <task>
			eEG = (Element) iEG.next(); //Element <exclusiveGateway>
			
			configIG=eIG.getAttributeValue("configurable"); // Attribut configurable de <inclusiveGateway> 
			directIG=eIG.getAttributeValue("gatewayDirection"); // Attribut gatewayDirection de <inclusiveGateway> 
			nomIG=eIG.getAttributeValue("name"); // Attribut name de <inclusiveGateway> 
	
			if(configIG.equals("Yes") && directIG.equals("Diverging") && nomIG.equals("s1")) // on v�rifie bien que c'est le connecteur S1
			{	
				for (String valIDIG : listIdIGs) // parcourir la liste de inclusiveGateway
				{
					if(listSourcesSFs.contains(valIDIG) && listTargetsSFs.contains(valIDIG) && stop==false) // on v�rifie bien que le connecteur poss�de une/plusieurs entr�e et une/plusieurs sortie
					{
						refTask=eTask.getAttributeValue("Ref"); //on prend Ref de <task>
						refIG = eIG.getAttributeValue("Ref"); // ref du connecteur S1
						
						listResultat.add("- " +refTask+ " "+refIG+" 0"); // le connecteur poss�de une entr�e de type <task>

						refEG=eEG.getAttributeValue("Ref"); //on prend Ref de <exclisiveGateway>
						
						eGNext =(Element)iIG.next(); // element next de eIG
						
						refGNext = eGNext.getAttributeValue("Ref"); // ref de next eIG
						
						listResultat.add("- "+refIG+" " +refEG+ " "+refGNext+" 0"); // le connecteur poss�de 2 sorties <exclusiveGateway> et <inclusiveGateway>

						stop = true; //resultat obtenu
						System.out.println("Etape 2-1 : Connecteur S1");
					}		
				}
			}
		} 
	}
	
	// M�thode pour le connecteur s2 : XOR, Diverging (Split) : 1 entr�e s1 (<inclusiveGateway>) et 2 sorties a2 (<task>) + a3 (<task>)
	static void connecteurS2() throws Exception
	{
		List <String> listSourcesSFs = afficheListAttributs("sequenceFlow","sourceRef"); // liste des sources de sequenceFlow
		List <String> listTargetsSFs = afficheListAttributs("sequenceFlow","targetRef"); // liste des targets de sequenceFlow
		List <String> listIdEGs = afficheListAttributs("exclusiveGateway","id"); // liste des exclusiveGateway
		
		List listIG = racine.getChildren("inclusiveGateway"); // liste des enfants <inclusiveGateway>
		List listTask = racine.getChildren("task"); // liste des enfants <task>
		List listEG = racine.getChildren("exclusiveGateway"); // liste des enfants <exclusiveGateway>
		
		Iterator  iIG = listIG.listIterator(); // iterator sur <inclusiveGateway>
		Iterator iTask = listTask.iterator(); // iterator sur <task>
		Iterator iEG = listEG.iterator(); // iterator sur <exclusiveGateway>
		
		Element eTaskNext,eIG,eTask,eEG;
		boolean stop = false; //stop prend true si le r�sultat est obtenu sinon false par d�faut
		
		while (iIG.hasNext() && iTask.hasNext() && iEG.hasNext()) //boucle pour parcourir tout le fichier XML
		{
			eIG = (Element) iIG.next(); //Element <inclusiveGateway>
			eTask= (Element) iTask.next(); //Element <task>
			eEG = (Element) iEG.next(); //Element <exclusiveGateway>
			
			directEG=eEG.getAttributeValue("gatewayDirection"); // Attribut gatewayDirection de <exclusiveGateway>
			nomEG=eEG.getAttributeValue("name"); // Attribut name de <exclusiveGateway>
			refEG=eEG.getAttributeValue("Ref"); // ref du connecteur s2
			
			if(directEG.equals("Diverging") && nomEG.equals("s2")) // on v�rifie bien que c'est le connecteur S2
			{	
				for (String valIDEG : listIdEGs) // parcourir la liste de exclusiveGateway
				{
					if(listSourcesSFs.contains(valIDEG) && listTargetsSFs.contains(valIDEG) && stop == false) // on v�rifie bien que le connecteur poss�de une/plusieurs entr�e et une/plusieurs sortie
					{
						refIG = eIG.getAttributeValue("Ref"); // ref de inclusiveGateway S1
						
						listResultat.add("- " +refIG+ " "+refEG+" 0"); // le connecteur poss�de une entr�e de type <inclusiveGateway>

						eTask= (Element) iTask.next(); // element next de task (next of a1)
						
						refTask=eTask.getAttributeValue("Ref"); // ref de task (a2)
						
						eTaskNext =(Element)iTask.next(); // element taskNext, le next de a2 (a3)
						
						refTNext = eTaskNext.getAttributeValue("Ref"); // ref de task (a3)
						
						listResultat.add(refEG+" -" +refTask+ " "+refTNext+" 0"); // le connecteur poss�de 2 sorties <task>(-8) et <task>(9)
						listResultat.add(refEG+" " +refTask+ " -"+refTNext+" 0"); // le connecteur poss�de 2 sorties <task>(8) et <task>(-9)

						stop = true; //resultat obtenu
						System.out.println("Etape 2-2 : Connecteur S2");
					}
				}
			}
		} 
	}
	
	// M�thode pour le connecteur J1 : XOR, Converging (Join) : 2 entr�es a2 (<task>) + a3 (<task>) et 1 sortie s3 (<inclusiveGateway>)
	static void connecteurJ1() throws Exception
	{
		List <String> listSourcesSFs = afficheListAttributs("sequenceFlow","sourceRef"); // liste des sources de sequenceFlow
		List <String> listTargetsSFs = afficheListAttributs("sequenceFlow","targetRef"); // liste des targets de sequenceFlow
		List <String> listIdEGs = afficheListAttributs("exclusiveGateway","id"); // liste des exclusiveGateway
		
		List listIG = racine.getChildren("inclusiveGateway"); // liste des enfants <inclusiveGateway>
		List listTask = racine.getChildren("task"); // liste des enfants <task>
		List listEG = racine.getChildren("exclusiveGateway"); // liste des enfants <exclusiveGateway>
		
		Iterator  iIG = listIG.listIterator(); // iterator sur <inclusiveGateway>
		Iterator iTask = listTask.iterator(); // iterator sur <task>
		Iterator iEG = listEG.iterator(); // iterator sur <exclusiveGateway>
		
		Element eTaskNext,eIG,eTask,eEG;
		boolean stop = false; //stop prend true si le r�sultat est obtenu sinon false par d�faut
		while (iIG.hasNext() && iTask.hasNext() && iEG.hasNext()) //boucle pour parcourir tout le fichier XML
		{
			eIG = (Element) iIG.next(); //Element <inclusiveGateway>
			eTask= (Element) iTask.next(); //Element <task>
			eEG = (Element) iEG.next(); //Element <exclusiveGateway>
			
			directEG=eEG.getAttributeValue("gatewayDirection"); // Attribut gatewayDirection de <exclusiveGateway>
			nomEG=eEG.getAttributeValue("name"); // Attribut name de <exclusiveGateway>
			refEG=eEG.getAttributeValue("Ref"); // ref du connecteur j1
			
			if(directEG.equals("Converging") && nomEG.equals("j1")) // on v�rifie bien que c'est le connecteur j1
			{	
				for (String valIDEG : listIdEGs) // parcourir la liste de exclusiveGateway
				{
					if(listSourcesSFs.contains(valIDEG) && listTargetsSFs.contains(valIDEG) && stop == false) // on v�rifie bien que le connecteur poss�de une/plusieurs entr�e et une/plusieurs sortie
					{
						eTaskNext =(Element)iTask.next(); // element next de task (next of a2) ==> a3
						
						eIG = (Element) iIG.next(); // element next de inclusiveGateway (next of s2) ==> s3

						refIG = eIG.getAttributeValue("Ref"); // ref de s3
						refTNext = eTaskNext.getAttributeValue("Ref"); // ref de a2
						refTask=eTask.getAttributeValue("Ref"); //ref de a3
						
						listResultat.add("-"+refTask+" " +refTNext+ " "+refEG+" 0"); // le connecteur poss�de 2 entr�es <task> (-8) et <task> (9)
						listResultat.add(refTask+" -" +refTNext+ " "+refEG+" 0"); // le connecteur poss�de 2 entr�es <task> (8) et <task> (-9)
						listResultat.add("- "+refEG+ " "+refIG+" 0"); //// le connecteur poss�de 1 sortie <inclusiveGateway> (5)
						stop = true; //resultat obtenu
						System.out.println("Etape 2-3 : Connecteur J1");
					}			 
				}
			}
		} 
	}
	
	// M�thode pour le connecteur J2 : OR, Configurable, Converging (Join) : 2 entr�es s1 (<inclusiveGateway>) + s3 (<inclusiveGateway>) et 1 sortie a5 (<task>)
	static void connecteurJ2() throws Exception
	{
		List <String> listSourcesSFs = afficheListAttributs("sequenceFlow","sourceRef"); // liste des sources de sequenceFlow
		List <String> listTargetsSFs = afficheListAttributs("sequenceFlow","targetRef"); // liste des targets de sequenceFlow
		List <String> listIdIGs = afficheListAttributs("inclusiveGateway","id"); // liste des inclusives
		
		List listIG = racine.getChildren("inclusiveGateway"); //Element <inclusiveGateway>
		List listTask = racine.getChildren("task"); //Element <task>
		List listEG = racine.getChildren("exclusiveGateway"); //Element <exclusiveGateway>
		
		ListIterator  iIG = listIG.listIterator(); // iterator sur <inclusiveGateway>
		Iterator iTask = listTask.iterator(); // iterator sur <task>
		Iterator iEG = listEG.iterator(); // iterator sur <exclusiveGateway>

		Element eGNext,eIG,eTask;
		boolean stop = false; //stop prend true si le r�sultat est obtenu sinon false par d�faut
		
		while (iIG.hasNext() && iTask.hasNext() && iEG.hasNext()) //boucle pour parcourir tout le fichier XML
		{
			eIG = (Element) iIG.next(); //Element <inclusiveGateway>
			eTask= (Element) iTask.next(); //Element <task>
			
			configIG=eIG.getAttributeValue("configurable"); // Attribut configurable de <inclusiveGateway>
			directIG=eIG.getAttributeValue("gatewayDirection"); // Attribut gatewayDirection de <inclusiveGateway>
			nomIG=eIG.getAttributeValue("name"); // Attribut name de <inclusiveGateway>
			refIG=eIG.getAttributeValue("Ref"); // Attribut ref de j2
		
			if(configIG.equals("Yes") && directIG.equals("Converging") && nomIG.equals("j2")) // on v�rifie bien que c'est le connecteur j2
			{	
				for (String valIDIG : listIdIGs) // parcourir la liste de inclusiveGateway
				{
					if(listSourcesSFs.contains(valIDIG) && listTargetsSFs.contains(valIDIG) && stop == false) // on v�rifie bien que le connecteur poss�de une/plusieurs entr�e et une/plusieurs sortie
					{
						eIG = (Element) iIG.previous(); //element j2
						eIG = (Element) iIG.previous(); //element s1
						
						refIGP = eIG.getAttributeValue("Ref"); //ref de s1 (1)
						
						listResultat.add("-"+refIGP+" " +refIG+ " 0");// 1ere ligne -1 4 0 (1 ref de s1, 4 ref de j2)
						
						eGNext =(Element)iIG.next(); //element s1
						eGNext =(Element)iIG.next(); //element j2
						eGNext =(Element)iIG.next(); //element s3
						
						refGNext = eGNext.getAttributeValue("Ref"); // ref de s3 (5)
						
						listResultat.add("-"+refGNext+" " +refIG+ " 0"); //2eme ligne -5 4 0 (5 ref de s3, 4 ref de j2)
						
						eTask= (Element) iTask.next();// task a3
						eTask= (Element) iTask.next();// task a4
						eTask= (Element) iTask.next();// task a5
						
						refTask=eTask.getAttributeValue("Ref"); //ref de a5
						
						listResultat.add("-"+refIG+" " +refTask+ " 0"); //ligne de sortie -4 11 0 (4 ref de j2, 11 ref de a5)
						stop = true; //resultat obtenu
						System.out.println("Etape 2-4 : Connecteur J2");
					}			 
				}
			}
		} 
	}
	
	// M�thode pour le connecteur S3 : OR, Configurable, Diverging (Split) : 1 entr�e j1 (<exclusiveGateway>) et 2 sorties j2 (<inclusiveGateway>) + a4 (<task>)
	static void connecteurS3() throws Exception
	{
		List <String> listSourcesSFs = afficheListAttributs("sequenceFlow","sourceRef"); // liste des sources de sequenceFlow
		List <String> listTargetsSFs = afficheListAttributs("sequenceFlow","targetRef"); // liste des targets de sequenceFlow
		List <String> listIdIGs = afficheListAttributs("inclusiveGateway","id"); // liste des inclusiveGateway
		
		List listIG = racine.getChildren("inclusiveGateway"); //Element <inclusiveGateway>
		List listTask = racine.getChildren("task"); //Element <task>
		List listEG = racine.getChildren("exclusiveGateway"); //Element <exclusiveGateway>
		
		ListIterator  iIG = listIG.listIterator(); // iterator sur <inclusiveGateway>
		ListIterator iTask = listTask.listIterator(); // iterator sur <task>
		Iterator iEG = listEG.iterator(); // iterator sur <exclusiveGateway>
		
		Element eIG,eTask,eEG;
		boolean stop = false; //stop prend true si le r�sultat est obtenu sinon false par d�faut
		
		while (iIG.hasNext() && iTask.hasNext() && iEG.hasNext()) //boucle pour parcourir tout le fichier XML
		{
			eIG = (Element) iIG.next(); // element S1
			eIG = (Element) iIG.next(); // element j2
			eIG = (Element) iIG.next(); // element S3
			
			eTask= (Element) iTask.next(); //Element task
			
			eEG = (Element) iEG.next(); // element s2
			eEG = (Element) iEG.next(); // element j1
			
			configIG=eIG.getAttributeValue("configurable"); // Attribut configurable de <inclusiveGateway>
			directIG=eIG.getAttributeValue("gatewayDirection"); // Attribut gatewayDirection de <inclusiveGateway>
			nomIG=eIG.getAttributeValue("name"); // Attribut name de <inclusiveGateway>
			refIG = eIG.getAttributeValue("Ref"); //ref de s3
			
			refEG=eEG.getAttributeValue("Ref"); //ref de j1
			
			if(configIG.equals("Yes") && directIG.equals("Diverging") && nomIG.equals("s3")) // on v�rifie bien que c'est le connecteur s3
			{	
				for (String valIDIG : listIdIGs) // parcourir la liste de inclusiveGateway
				{
					if(listSourcesSFs.contains(valIDIG) && listTargetsSFs.contains(valIDIG) && stop==false) // on v�rifie bien que le connecteur poss�de une/plusieurs entr�e et une/plusieurs sortie
					{
						listResultat.add("- " +refEG+ " "+refIG+" 0"); // -3 5 0 (3 ref de j1, 5 ref de s3)
						
						eIG = (Element) iIG.previous();//IG s3
						eIG = (Element) iIG.previous(); // avant s3 ==> j2
						
						refIGP = eIG.getAttributeValue("Ref"); //ref de j2 (4)
						
						eTask = (Element)iTask.next(); // task a2
						eTask = (Element)iTask.next(); //task a3
						eTask = (Element)iTask.next(); // task a4
						
						refTask=eTask.getAttributeValue("Ref"); // ref de a4 (10)
						
						listResultat.add("- "+refIG+" " +refIGP+ " "+refTask+" 0"); // -5 4 10 0 (5 ref de s3, 4 ref de j2 et 10 ref de a4)
						
						stop = true; //resultat obtenu
						System.out.println("Etape 2-5 : Connecteur S3");
					}		
				}
			}
		} 
	}
	
	// M�thode pour le connecteur j3 : OR, Configurable, Converging (Join) : 2 entr�e a4 (<task>) + a6 (<task>) et 1 sortie a7 (<task>)
	static void connecteurJ3() throws Exception
	{
		List <String> listSourcesSFs = afficheListAttributs("sequenceFlow","sourceRef"); // liste des sources de sequenceFlow
		List <String> listTargetsSFs = afficheListAttributs("sequenceFlow","targetRef"); // liste des targets de sequenceFlow
		List <String> listIdIGs = afficheListAttributs("inclusiveGateway","id"); // liste des inclusiveGateway
		
		List listIG = racine.getChildren("inclusiveGateway"); //Element <inclusiveGateway>
		List listTask = racine.getChildren("task"); //Element <task>
		List listEG = racine.getChildren("exclusiveGateway"); //Element <exclusiveGateway>
		
		ListIterator  iIG = listIG.listIterator(); // iterator sur <inclusiveGateway>
		Iterator iTask = listTask.iterator(); // iterator sur <task>
		Iterator iEG = listEG.iterator(); // iterator sur <exclusiveGateway>
		
		Element eIG,eTask;
		boolean stop = false; //stop prend true si le r�sultat est obtenu sinon false par d�faut
		
		while (iIG.hasNext() && iTask.hasNext() && iEG.hasNext()) //boucle pour parcourir tout le fichier XML
		{
			eIG = (Element) iIG.next(); // S1
			eIG = (Element) iIG.next(); // J2
			eIG = (Element) iIG.next(); // S3
			eIG = (Element) iIG.next(); // J3
			
			eTask= (Element) iTask.next(); // task a1
			eTask = (Element) iTask.next(); // task a2
			eTask = (Element) iTask.next(); // task a3
			eTask = (Element) iTask.next(); // task a4
			refTask=eTask.getAttributeValue("Ref"); //ref de a4 (10)

			configIG=eIG.getAttributeValue("configurable"); // Attribut configurable de <inclusiveGateway>
			directIG=eIG.getAttributeValue("gatewayDirection"); // Attribut gatewayDirection de <inclusiveGateway>
			nomIG=eIG.getAttributeValue("name"); // Attribut name de <inclusiveGateway>
			refIG = eIG.getAttributeValue("Ref"); // Attribut ref de J3 (6)
			
			if(configIG.equals("Yes") && directIG.equals("Converging") && nomIG.equals("j3")) // on v�rifie bien que c'est le connecteur j3
			{	
				for (String valIDIG : listIdIGs) // parcourir la liste de inclusiveGateway
				{
					if(listSourcesSFs.contains(valIDIG) && listTargetsSFs.contains(valIDIG) && stop == false) // on v�rifie bien que le connecteur poss�de une/plusieurs entr�e et une/plusieurs sortie
					{
						listResultat.add("-"+refTask+" " +refIG+ " 0"); // 1ere ligne -10 6 0 (10 ref de a4 et 6 ref de j3)
						
						eTask= (Element) iTask.next(); // a5
						eTask= (Element) iTask.next(); //a6
						
						refTask=eTask.getAttributeValue("Ref"); // ref de a6 (12)
						
						listResultat.add("-"+refTask+" " +refIG+ " 0"); // 2eme ligne -12 6 0 (12 ref de a6 et 6 ref de j3)
						
						eTask= (Element) iTask.next(); // a7
						
						refTask=eTask.getAttributeValue("Ref"); // ref de a7
						
						listResultat.add("-"+refIG+" " +refTask+ " 0"); // ligne de sortie -6 13 0 (6 ref de j3 et 13 ref de a4)
						
						stop = true; // resultat obtenu
						System.out.println("Etape 2-6 : Connecteur J3");
					}			 
				}
			}
		} 
	}
	
	//M�thode pour enregistrer le r�sultat obtenu sous forme d'un fichier TXT
	static void EnregistrerTxt () throws Exception
	{
		try
		{
			File file = new File("../JUCS/txt_bpmn");
			if(file.mkdir()) 
			{
				FileWriter myWriter = new FileWriter("txt_bpmn/bpmn.txt"); // cr�ation d'un nouveau fichier txt
				BufferedWriter tampon = new BufferedWriter(myWriter); // tampon
				PrintWriter sortie = new PrintWriter(tampon);
			
				//pour chaque element de la liste listResultat on l'enregistre dans le fichier txt
				for (String s : listResultat)
				{
					sortie.println(s);
				}
				sortie.flush();
				sortie.close();
				System.out.println("Etape 3 : Le fichier Txt est enregistr�.");
			}
		}
		catch (IOException e)
		{
			System.out.println("Une erreur c'est produite.");
			e.printStackTrace();
		}
	}

	// M�thode pour cr�er des listes des attributs "id" et les sauvegarder
	static List <String> afficheListAttributs (String nomElement, String nomAttribut)
	{
		List listElement = racine.getChildren(nomElement);
		List <String> listElemetF = new <String> ArrayList();
		Iterator iElemnt = listElement.iterator();
		while (iElemnt.hasNext())
		{
			element = (Element) iElemnt.next();
			List attributList = element.getAttributes();
			Iterator iAttribut = attributList.iterator();
			while (iAttribut.hasNext())
			{
				Attribute attribut = (Attribute) iAttribut.next();
				String nomAttList = attribut.getName();
				if(nomAttList.equals(nomAttribut))
				{
					valAttributElement = attribut.getValue();
					listElemetF.add(valAttributElement);
				}
			}
		}
		return listElemetF;
	}
}
